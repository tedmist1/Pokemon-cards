import math
extension = 'etb.txt'

f = open(extension, "r")

# problem: this reads all the lines. We dont want to read all the lines until we're ready.
#line_count = len(f.readlines())

line_count = 11000

items = []

for l in range(math.ceil(line_count/4)):
    date = f.readline()
    status = f.readline()
    count = f.readline()
    price = f.readline()
    items.append((date, status, count, price))

print(items)



# for l in f:
