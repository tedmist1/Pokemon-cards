import sys
import requests
import re
import time
from PyQt5 import QtCore, QtGui, QtWidgets
from bs4 import BeautifulSoup
from selenium import webdriver
from selenium.webdriver.common.by import By

# Basic scraper for tcgplayer. Need to fix some constant variables and make this more adaptable so I can gather data from other products. 
# Output data is just a text file with each data point taking up 4 lines. Needs to be handled in post-process to put into csv.



# Finds the button to load more elements
def hit_load_button(num=100):
    for i in range(num): # Probably should change to be not 100 times but some varying amount of time
        load_more_button = browser.find_element(By.XPATH, "//*[@class='price-guide-modal__load-more']")
        load_more_button.click()
        time.sleep(1)



# Launch web-driver
URL = "https://www.tcgplayer.com/product/242811/pokemon-celebrations-celebrations-elite-trainer-box?Language=English"
browser = webdriver.Firefox()
browser.get(URL)
time.sleep(3)
html = browser.page_source



# class tag to find the "view sales history" button
input = browser.find_element(By.XPATH, "//*[@class='svg-inline--fa fa-chevron-right fa-w-10']")
input.click()

# SUCCESS! able to open up data here
time.sleep(2)

hit_load_button(110) # Should eliminate this magic number and determine how to stop when fully done

output = browser.find_element(By.XPATH, "//*[@class='is-modal']")
print(output.text) # Needs to be fed into a file

# Used to write whole thing to a file
#browser_updated = browser.page_source
# print(browser_updated)



browser.quit()


